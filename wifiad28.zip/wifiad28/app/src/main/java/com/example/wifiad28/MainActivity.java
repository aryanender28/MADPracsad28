package com.example.wifiad28;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageButton imgon;
    ImageButton imgoff;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imgon = findViewById(R.id.wion);
        imgoff = findViewById(R.id.wioff);
        imgon.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                WifiManager wi=
                        (WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE)
                        ;

                wi.setWifiEnabled(true);
                Toast.makeText(MainActivity.this, "Wifi Enabled",
                        Toast.LENGTH_SHORT).show();
                imgon.setVisibility(View.INVISIBLE);
                imgoff.setVisibility(View.VISIBLE);
            }
        });
        imgoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                WifiManager wi=
                        (WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                wi.setWifiEnabled(false);
                Toast.makeText(MainActivity.this, "Wifi Disabled",
                        Toast.LENGTH_SHORT).show();
                imgon.setVisibility(View.VISIBLE);
                imgoff.setVisibility(View.INVISIBLE);
            }
        });

    }
}
